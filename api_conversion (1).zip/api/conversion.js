
export default async function handler(req, res) {
  const { event_name, email } = req.body;

  const crypto = await import('crypto');
  const hashedEmail = email
    ? crypto.createHash('sha256').update(email).digest('hex')
    : null;

  const body = {
    data: [
      {
        event_name: event_name || 'Lead',
        event_time: Math.floor(Date.now() / 1000),
        action_source: "website",
        event_source_url: "https://ganamos.vercel.app",
        user_data: {}
      }
    ]
  };

  if (hashedEmail) {
    body.data[0].user_data.em = hashedEmail;
  }

  const response = await fetch(
    `https://graph.facebook.com/v18.0/1196008671864934/events?access_token=${process.env.META_ACCESS_TOKEN}`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body)
    }
  );

  const result = await response.json();
  res.status(200).json(result);
}
